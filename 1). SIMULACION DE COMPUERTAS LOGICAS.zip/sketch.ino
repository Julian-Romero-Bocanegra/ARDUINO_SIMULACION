void setup() {
  pinMode(2, INPUT);   // Pulsador A
  pinMode(3, INPUT);   // Pulsador B
  pinMode(8, OUTPUT);  // LED Rojo (AND)
  pinMode(9, OUTPUT);  // LED Amarillo (OR)
  pinMode(10, OUTPUT); // LED Verde (NOT de A)
}

void loop() {
  int a = digitalRead(2);
  int b = digitalRead(3);

  // AND: Solo enciende si ambos son 1
  digitalWrite(8, (a == HIGH && b == HIGH));

  // OR: Enciende si cualquiera es 1
  digitalWrite(9, (a == HIGH || b == HIGH));

  // NOT: Enciende si A es 0, apaga si A es 1
  digitalWrite(10, !a);
}