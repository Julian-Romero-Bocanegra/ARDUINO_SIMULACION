const int segmentos[] = {6, 7, 8, 9, 10, 11, 12};
// Mapa para Ánodo Común (0 enciende, 1 apaga)
const byte hexMap[16] = {
  0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 
  0x00, 0x10, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E
};

void setup() {
  for (int i = 2; i <= 5; i++) pinMode(i, INPUT);
  for (int i = 0; i < 7; i++) pinMode(segmentos[i], OUTPUT);
}

void loop() {
  // Leer los 4 bits (1, 2, 4, 8)
  int valor = digitalRead(2) * 1 + 
              digitalRead(3) * 2 + 
              digitalRead(4) * 4 + 
              digitalRead(5) * 8;

  byte patron = hexMap[valor];
  for (int i = 0; i < 7; i++) {
    digitalWrite(segmentos[i], bitRead(patron, i));
  }
  delay(100);
}