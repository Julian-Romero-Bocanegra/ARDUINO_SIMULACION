// Definición de pines para el semáforo
const int ledRojo = 13;
const int ledAmarillo = 12;
const int ledVerde = 11;

void setup() {
  // Configurar los pines como salida
  pinMode(ledRojo, OUTPUT);
  pinMode(ledAmarillo, OUTPUT);
  pinMode(ledVerde, OUTPUT);
}

void loop() {
  // 1. VERDE: El tráfico fluye (5 segundos)
  digitalWrite(ledVerde, HIGH);
  digitalWrite(ledAmarillo, LOW);
  digitalWrite(ledRojo, LOW);
  delay(5000); 

  // 2. AMARILLO: Precaución, va a cambiar (2 segundos)
  digitalWrite(ledVerde, LOW);
  digitalWrite(ledAmarillo, HIGH);
  delay(2000);

  // 3. ROJO: El tráfico se detiene (5 segundos)
  digitalWrite(ledAmarillo, LOW);
  digitalWrite(ledRojo, HIGH);
  delay(5000);
}